@echo off
setlocal
echo Setting up ESP32 Excel Extension...

:: Define the destination folder
set "DEST_DIR=%APPDATA%\Microsoft\Excel\WEF\Developer"

:: Create the folder if it doesn't exist
if not exist "%DEST_DIR%" mkdir "%DEST_DIR%"

:: The magic: %~dp0 tells the script to look in its OWN folder
copy "%~dp0ESP32_Excel_Streamer.xml" "%DEST_DIR%\ESP32_Excel_Streamer.xml"

echo.
echo ==================================================
echo Setup Complete! 
echo ==================================================
echo 1. Open Excel Desktop.
echo 2. Go to "Insert" -> "Add-ins" -> "My Add-ins".
echo 3. Click "ESP32 Data Streamer".
echo.
pause